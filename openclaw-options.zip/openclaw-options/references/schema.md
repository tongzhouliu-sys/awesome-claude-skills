# OpenClaw 扫描器输出 Schema

> **版本**：v3.1（兼容 v3.0 / v2.1）·对应脚本 `openclaw_scan.py`
> **触发**：文件名形如 `LLM_YYYYMMDD_HHMM.txt`，内容以 `{"m":{...` 开头

---

## 文件整体结构

```
{
  "m":      { ...meta... },      // 市场环境 + Gate 状态 + 扫描范围
  "sig":    [ ...signals... ],   // 通过筛选的标的（可能为空）
  "skip":   { ...skip_info... }, // 被跳过标的汇总（v3.x 压缩分类；v2.1 文字）
  "legend": { ... }              // 可选，仅 --with-legend 时出现
}
```

**紧凑化规则**：值为 `null` 的字段被省略。字段不存在 ≠ 数据异常。

---

## `m` (meta) 字段

| 字段 | 类型 | 含义 |
|---|---|---|
| `ts` | string | 扫描时间戳 `YYYY-MM-DD HH:MM:SS` |
| `ver` | string | 脚本版本号（v3.1/v3.0/v2.1） |
| `vix` | number | VIX 现价（CBOE 官方优先） |
| `vix3m` | number | VIX3M 现价（用于期限结构） |
| `term` | string | 期限结构 `NORMAL` / `INVERTED` |
| `sp_ma200` | bool | SP500 是否在 200MA 上方 |
| `sp_dd20` | number | SP500 相对 20 日峰值回撤%（正=回撤；0=高点；负=创新高） |
| `gates_ok` | bool | 5 项 Pre-screen Gate 是否全通过（false 时 sig 为空） |
| `gate_score` | int | 三因子得分（0-100；≥50 通过；≥80 友好） |
| `fomc_d` | int | 距下次 FOMC 天数 |
| `cpi_d` | int | 距下次 CPI 天数（v3.x） |
| `nfp_d` | int | 距下次非农天数（v3.x） |
| `boj_d` | int | 距下次 BOJ 天数（v3.x） |
| `scope` | string | 扫描范围 `preferred` / `full`（v3.x；v2.1 缺失视为 preferred） |
| `off_cnt` | int | 官方标的数量（v3.x） |
| `sug_cnt` | int | 扩展标的数量（v3.x） |
| `sig_cnt` | string | `"{信号数}/{总扫描数}"` |
| `hv_proxy_count` | int | 走 HV 代理的标的数 |
| `hv_proxy_sig_count` | int | 信号列表中走 HV 代理的数量 |
| `margin` | object | 保证金状态；**缺失 = Gate-4 软通过** |
| `d_adj` | number | DELTA_MIN 收紧量（仅期限结构倒挂时出现） |

---

## `sig` 数组字段

### 顶层字段

| 字段 | 含义 |
|---|---|
| `tkr` | 股票代码 |
| `g` | 风险评级 `A+`/`A`/`B`/`C` |
| `off` | 是否官方标的（v3.x；**键不存在=扩展池**；v2.1 缺失视为 true） |
| `sec` | 行业分类（v3.x） |
| `cc` | 合规/上下文规则标签 |
| `px` | 标的现价 |
| `dte` | 到期天数 |
| `exp` | 到期日 `YYYY-MM-DD` |
| `ivr` | IVR（0-100） |
| `ivs` | IVR 来源 `real` / `hv` |
| `ivt` | IV 趋势（v3.x 短码：`?`/`up`/`dn`/`fl`；v2.1 全称：`unknown`/`rising`/`falling`/`flat`） |
| `earn` | 距财报天数（正=前；负=后；null=未知） |
| `earn_note` | 财报上下文（仅 earn<0 时出现） |
| `opp` | Opportunity Alert 摘要（见下） |
| `warn` | 警告代码列表 |
| `th` | 筛选阈值 `{ivr_min, ann_min, otm_buf}`（分析时对比实际值） |
| `c` | 候选合约列表 |

### `opp` 子字段

| 字段 | 含义 |
|---|---|
| `t` | 全部 5 项条件触发 |
| `p` | 仅 C1 触发（参考用） |
| `cd` | 连续收阴天数 |
| `p5d` / `p3d` | 5日/3日价格涨跌幅%（负=下跌） |
| `c1_5d` / `c1_3d` | 是否满足 5日/3日跌幅门槛 |
| `d5` | IVR 5日变化（百分点） |
| `fail` | `p=true` 时列出未满足条件 key |

---

## `c` (contract) 数组字段

| 字段 | 含义 |
|---|---|
| `k` | 行权价 |
| `del` | Delta（卖 PUT 为负） |
| `yld` | 年化收益%（CSP：`prem/k×365/dte×100`；价差：`净权利金/宽度×365/dte×100`） |
| `otm` | OTM 深度%：`(px-k)/px×100` |
| `prem` | 中间价权利金 |
| `spd` | 买卖价差% |
| `oi` | 持仓量 |
| `vol` | 当日成交量 |
| `gs` | Greeks 来源：`r`=真实；`bs`=Black-Scholes |
| `str` | 策略结构短码 |

**`str` 策略短码**：
- `csp` = 现金担保卖 PUT
- `csp_spread` = CSP 但建议改价差
- `bps` = Bull Put Spread
- `fbps` = 强制 Bull Put Spread
- `fspread` = 强制价差（通用）

---

## `skip` 字段

### v3.x 压缩分类

| 字段 | 含义 |
|---|---|
| `count` | 被跳过总数 |
| `nc` | 无合格合约（ticker 列表） |
| `ebl` | 财报阻断：`SYM(days)` |
| `eunk` | 财报日期未知，保守阻断 |
| `pebl` | `--block-post-earnings` 阻断 |
| `ivrl` | IVR 低于门槛：`SYM(current_ivr)` |
| `ivu` | IVR 缺失/无法计算 |
| `gld` | GLD VIX 闸门阻断：`GLD(vix)` |
| `fomc` / `cpi` / `nfp` / `boj` | 宏观阻断窗口：`SYM(days)` |
| `nt` | 无信号触发（兜底） |
| `err` | 数据异常：`SYM:message` |
| `drop` | ⚡ Opportunity Alert：`SYM:type(pct%)` |

### v2.1 文字格式

逗号分隔字符串，例：`"EWJ(无合格合约), GLD(gld_vix(18.1)), TSLA(earn_bl(6d))"`。按 `SYM(原因)` 逐条拆分，⚡ 后缀=Opportunity Alert。

---

## Warn Codes

| 代码 | 含义 |
|---|---|
| `earn_bl` | 在财报阻断窗口 |
| `near_blackout` | 接近财报阻断（缓冲期内） |
| `earn_unk` | 财报日获取失败，保守处理 |
| `post_earnings_vol` | 财报后 IV crush 窗口 |
| `post_earn_bl` | 被 `--block-post-earnings` 阻断 |
| `fomc_bl` / `cpi_bl` / `nfp_bl` / `boj_bl` | 宏观阻断窗口 |
| `gld_vix_blocked` | GLD 被 VIX<22 机制阻断 |
| `hv_proxy` | IVR 用 HV 代理（非真实 IV） |
| `iv_rising` | IV 趋势上升（卖方不利） |
| `iv_rising_blocked` | IV 上升 + strict flag 共同阻断 |
| `ivt_unknown` | IV 趋势数据不足 |
| `dte:N` | DTE 落在 fallback 区间 |
| `cc:价差` | 合规规则要求价差结构 |
| `cc:暂停` | 合规规则要求暂停 |

---

## 关键解析注意事项

1. **`off` 判断**：v3.x 键存在=官方；键不存在=扩展池，参数推断必须注明。v2.1 全部视为官方。
2. **`scope` + `sug_cnt`**：preferred + sug_cnt=0=纯核心池；full + sug_cnt>0=含扩展，官方优先。
3. **`sp_dd20`**：正=回撤 | 0=高点 | 负=创新高。
4. **HV 代理全覆盖**：`hv_proxy_count` 接近总数时，IVR 仅供粗略参考，明确提示"本轮所有 IVR 都是近似值，决策打折"。
5. **`margin` 缺失**：每次必提醒"Gate-4 未核验，开仓前请在 IBKR 确认保证金 <55%"。
6. **v2.1 降级**：检测 `m.ver == "v2.1"` 时提示"兼容模式解析，新字段缺失属正常"，其余逻辑不变。

---

⚠️ 本文档仅描述扫描器输出格式，不构成任何投资建议。
