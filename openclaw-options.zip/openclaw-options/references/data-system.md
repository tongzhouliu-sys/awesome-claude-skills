# OpenClaw 数据系统要点

> **用途**：Pre-screen Gate 的数据来源 + 多数据源降级策略 + IV 库冷启动说明
> **与 SKILL.md 的分工**：SKILL.md 给 Gate 的触发规则（速查）；本文件给数据源降级细节

---

## Pre-screen Gate 数据来源

每次扫描循环开头执行。任一失败则终止本轮全部扫描，**零期权链 API 调用**（节省 40-60% 无效请求）。

| Gate | 规则 | 数据源 | 失败动作 |
|---|---|---|---|
| 1 · 市场状态 | 非 D 级（SPX > MA50 或 MA20 向上） | yfinance `^GSPC` | 终止 |
| 2 · VIX 硬上限 | VIX ≤ 35 | CBOE 官方 JSON，fallback `^VIX` yfinance | 终止 |
| 3 · 期限结构 | VIX > VIX3M 时 DELTA_MIN 从 -0.30 收紧到 -0.28 | CBOE（同批次） | 仅调参，不终止 |
| 4 · 保证金使用率 | `margin_used < 55%` | CLI `--margin-used X` | 终止；未传则软通过 |
| 5 · 三因子得分 | 得分 ≥ 50 | 本地计算 | 终止 |

**Gate-5 评分**：VIX（<20=35 / <28=25 / <35=15 / else=0）+ SP500（>MA200=30 / 回撤<5%=15 / else=5）+ 期限结构（NORMAL=25 / unknown=15 / INVERTED=5）。≥80 环境友好；50-79 通过但不理想。

**Gate-4 软通过提醒**：`m.margin` 缺失时，Claude 必须提醒"开仓前请在 IBKR 确认保证金 <55%"。

---

## 数据源分层（T0-T4）

`openclaw_scan.py` 的 `DataRouter` 按健康度自动路由。

| 层级 | 数据源 | 额度 | 核心作用 |
|---|---|---|---|
| T0 | **Massive API** | 5 key 轮询，每 key 20s 冷却 | 完整期权链 + Greeks + K 线（主力） |
| T1 | Alpaca Paper | 200 req/min | 期权链 + 历史 |
| T2 | Tradier | 120 req/min | 完整期权链 + 实时 Greeks |
| T3 | Polygon.io | 5 req/min | 期权链备份 |
| T4 | yfinance | 无官方限制 | 股票历史 + 期权链（**无实时 Greeks，退化到 BS**） |

**CBOE API** 单独用于 VIX / VIX3M（Pre-screen Gate 依赖）。

**健康度机制**：成功 +5（上限 100），失败 -30（下限 0），401/403 直接 =0 永久排除。路由选 health 最高的可用源。

**Symbol 映射**：某些标的在某些源不可用（如 yfinance 无 SPX / OESX），`translate_symbol` 返回 None 时自动跳到下一个源（不扣 health）。所有源都 None → 抛 RuntimeError，标记 `status=ERROR`。

---

## IV 历史库冷启动

`calculate_real_ivr` 需 ≥30 条历史快照才切到真实 IVR，否则退化到 HV 代理。

**冷启动症状**（LLM JSON 中）：
- `m.hv_proxy_count` 接近总数（如 19/20）
- 所有 signal 的 `ivs:"hv"` + `ivt:"unknown"`
- Claude 必须提示："本轮所有 IVR 都是近似值，决策需打折扣"

**加速**：每日至少跑一次扫描（`save_iv_snapshot` 自动写入当日快照），30 天后切到真实 IVR。启动时 `_iv_history_health_check()` 检查 IV 库近 30 天覆盖率，<50% 红字警告。

---

## 数据库与缓存（简化版）

**当前**：单表 SQLite `iv_history.db` 存 ATM IV 快照；L1 进程内存缓存（TTL 30s）避免同轮重复查询。

**核心设计原则**：
- 先解决"该不该打"（Pre-screen Gate 前置），再解决"怎么打慢"（限流）
- 双时间戳：`api_response_time` + `data_timestamp`，区分"API 响应时间"和"数据代表的市场时间"
- 数据溯源：记录 `data_source` + `lineage_id`，便于 T+1 校验

**生产级扩展**（未实现）：四层数据库分离（原始/校准/计算/信号）+ Redis L2 + PostgreSQL hypertable + T+1 OCC 结算价校准。核心铁律：**AI 不直接修改策略规则文件**，参数调整必须人工 `git commit`。

---

⚠️ 本内容仅为架构参考，不构成任何投资建议。
